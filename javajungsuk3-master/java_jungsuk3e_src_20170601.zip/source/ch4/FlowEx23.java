class FlowEx23 {
	public static void main(String[] args) { 
		int i= 5;

		while(i--!=0) {
			System.out.println(i + " - I can do it.");
		}
	} // main�� ��
}
